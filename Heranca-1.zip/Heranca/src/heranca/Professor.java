/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca;

/**
 *
 * @author 051968
 */
public class Professor extends Funcionario {
    
    private int carga_horaria;
    private String titulacao;
    
    public void SetCarga(){
        System.out.print("Digite a Carga Horária: ");
        this.carga_horaria=entrada.nextInt();
    }
    
    public int GetCarga(){
        return this.carga_horaria;
    }
    
    public void ExibeCarga(){
        System.out.print(" - Carga Horária: "+carga_horaria);
    }
    public void SetTit(){
        System.out.print("Digite a Titulação: ");
        this.titulacao=entrada.nextLine();
    }
    
    public String GetTit(){
        return this.titulacao;
    }
    
    public void ExibeTit(){
        System.out.print(" - Titulação : "+titulacao);
    }
    
}
