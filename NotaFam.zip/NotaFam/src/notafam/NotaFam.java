/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notafam;

/**
 *
 * @author lcmlu
 */
public class NotaFam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Nota n = new Nota();
        n.EntrarNomeAluno();
        n.EntrarDisciplina();
        n.EntrarNotas();
        n.ValidarNota(n.a1, n.a2,n.a3);
        if(n.resp!=1){
           n.CalMedia(n.a1, n.a2);
           n.CalcStatus1(n.media);
           if (n.status!="aprovado"){
                n.EntrarNotaA3();
                n.ValidarNota(n.a1, n.a2,n.a3);
                if(n.resp!=1){
                    n.SubstituirNota(n.a1, n.a2, n.a3);
                    n.CalcStatus2(n.media);
                }
                else{
                    n.Sair();
                }
            }
            n.ExibeBoletim(n.a1, n.a2, n.a3, n.media, n.nome, n.status,n.disciplina);
        }
        else{
            n.Sair();
        }
        
    }
    }
    

