/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notafam;
import java.util.Scanner;

/**
 *
 * @author lcmlu
 */
public class Nota {
    
    Scanner entrada = new Scanner(System.in);
    double a1,a2,a3,media;
    String status,nome,disciplina;
    int resp;
            
    public void EntrarNotas(){
        System.out.print("Digite a nota A1: ");
        a1=entrada.nextDouble();
        System.out.print("Digite a nota A2: ");
        a2=entrada.nextDouble();
    }

    public void EntrarNotaA3(){
        System.out.print("Digite a nota A3: ");
        a3=entrada.nextDouble();

}
       
    public int ValidarNota(double a1,double a2,double a3){
        if((a1<0)||(a1>5)||(a2<0)||(a2>5)||(a3<0)||(a3>5)){
            System.out.println("Nota Inválida!");
            resp=1;
        }
        
        return resp;
    }
        
    public double CalMedia(double nota1,double nota2){
        media=nota1+nota2;
        return media;
    }
    public String CalcStatus1(double media){
        if(media>=6){
            status="aprovado";
            
        }
        else{
            System.out.println("Aluno não alcançou a média, precisa fazer A3");
            status="A3";
        }
        
        return status;
    }
    public String CalcStatus2(double media){
        if(media>=6){
            status="aprovado";
            
        }
        else{
            status="reprovado";
        }
        
        return status;
    }
    
    public String EntrarNomeAluno(){
        System.out.print("Informe o nome do Aluno: ");
        nome=entrada.nextLine();
        return nome;
    }
    
    
    public void ExibeBoletim(double nota1, double nota2, double nota3, double nota4,String nome,String status,String disciplina){
        System.out.println("*****BOLETIM DO ALUNO*****");
        System.out.println("Aluno:"+nome);
        System.out.println("Disciplina:"+disciplina);
        System.out.println("Nota A1:"+nota1);
        System.out.println("Nota A2:"+nota2);
        System.out.println("Nota A3:"+nota3);
        System.out.println("Nota Final:"+nota4);
        System.out.println("Situação: Aluno "+status);
        System.out.println("**************************");
        
        
    }
    public String EntrarDisciplina(){
        
        System.out.print("Digite o nome da Disciplina: ");
        disciplina=entrada.nextLine();
        return disciplina;
        
        
    }
    public void Sair(){
        System.out.print("***SISTEMA ENCERRADO****");
        System.exit(0);
    }
    
    public double SubstituirNota(double a1,double a2,double a3){
        if(a3>a1){
            media=a3+a2;
        }
        else{
            if(a3>a2){
                media=a3+a1;
            }
            else{
                media= a1+a2;
            }
        }
        return media;
        
    }
    
}
