/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;
import java.util.Scanner;
/**
 *
 * @author 051968
 */
public class Operacoes {
    int n1,n2,res,opc;
    Scanner entrada = new Scanner(System.in);
    
    
    public void Menu(){
        System.out.println("**MENU DA CALCULADORA*");
        System.out.println("* 1 - SOMA           *");
        System.out.println("* 2 - Subtração      *");
        System.out.println("* 3 - Multiplicação  *");
        System.out.println("* 4 - Divisão        *");
        System.out.println("* 5 - Sair do Sistema *");
        System.out.println("**********************");
               
    }
    
    public void Sair(){
        System.out.println("SISTEMA ENCERRADO!");
        System.exit(0);
    }
    public void ExibirMsg(){
        System.out.println("OPÇÃO INVÁLIDA!");
    }
    
    public int EscolherOpc(){
        System.out.println("Informe a opção desejada:");
        opc=entrada.nextInt();
        return opc;
    }
    
    public void EntrarNumeros(){
        System.out.print("Digite o Primeiro Numero: ");
        n1=entrada.nextInt();
        System.out.print("Digite o Segundo Numero: ");
        n2=entrada.nextInt();
        System.out.println("Primeiro Numero: "+n1);
        System.out.println("Segundo Numero: "+n2);
    }
    
    public void Soma(int x, int y){
        res=x+y;
        System.out.println("***************************");
        System.out.println("*Operação Escolhida:Adição*");
        System.out.println(x+" + "+y+" = "+res);
              
    }
     public void Subtrair(int x, int y){
        res=x-y;
        System.out.println("***************************");
        System.out.println("*Operação Escolhida:Subtração*");
        System.out.println(x+" - "+y+" = "+res);
              
    }
    public void Multiplicar(int x, int y){
        res=x*y;
        System.out.println("***************************");
        System.out.println("*Operação Escolhida:Multiplicação*");
        System.out.println(x+" x "+y+" = "+res);
              
    }
    public void Dividir(int x, int y){
        res=x/y;
        System.out.println("***************************");
        System.out.println("*Operação Escolhida:Divisão*");
        System.out.println(x+" / "+y+" = "+res);
              
    }
    
}
