/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

/**
 *
 * @author 051968
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
        Operacoes op = new Operacoes();
        do{
            op.Menu();
            op.EscolherOpc();
            if(op.opc==1){
                op.EntrarNumeros();
                op.Soma(op.n1,op.n2);
            }
            if(op.opc==2){
                op.EntrarNumeros();
                op.Subtrair(op.n1,op.n2);
            }
            if(op.opc==3){
                op.EntrarNumeros();
                op.Multiplicar(op.n1,op.n2);
            }
            if(op.opc==4){
                op.EntrarNumeros();
                op.Dividir(op.n1,op.n2);
            }
            if(op.opc==5){
                op.Sair();
            }
            if((op.opc<1)||(op.opc>5)){
                op.ExibirMsg();
            }
        }while(op.opc!=5);
        
                
        
        
        
        
    }
    
}
