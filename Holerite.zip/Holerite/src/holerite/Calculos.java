/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holerite;
import java.util.Scanner;
/**
 *
 * @author lcmlu
 */
public class Calculos {
    
    Scanner entrada = new Scanner(System.in);
    double taxa_aumento,salario_atual,valor_aumento,salario_novo,vlr_inss,tx_inss,vlr_ir,tx_ir,salario_final;
    String nome;
    
    public double ExibeMsg(){
        System.out.println("********CÁLCULO SALARIAL*******");
        System.out.print("Informe o Salário: ");
        salario_atual=entrada.nextDouble();
        return salario_atual;
        
    }
    
   
    public double AumentoSalarial(double sa){
        System.out.print("Informe a Taxa Porcentual de Aumento Salarial: ");
        taxa_aumento=entrada.nextDouble();
        valor_aumento=(sa*taxa_aumento/100);
        return valor_aumento;
        
    }
    
    public double CalcSalarioNovo(double va,double sa){
        salario_novo=sa+va;
        return salario_novo;
        
    }
    
    public double CalcValorInss(double sn){
        System.out.print("Informe a taxa do INSS: ");
        tx_inss=entrada.nextDouble();
        vlr_inss=(sn*tx_inss/100);
        return vlr_inss;
        
    }
    
    public double CalcValorIr(double sn){
        
        if(sn<=1900){
            tx_ir=0;
        }
        else if ((sn>=1901)&&(sn<=3000)){
            tx_ir=15;
        }
        else if ((sn>=3001)&&(sn<=11000)){
            tx_ir=27.5;
        }
        else {
            tx_ir=35;
        }
        vlr_ir=(sn*tx_ir/100);
        return vlr_ir;
        
    }

    public double CalcSalFinal(double sn, double vlr_inss,double vlr_ir){
        salario_final=sn-vlr_inss-vlr_ir;
        return salario_final;
    }
    
    public String EntrarNome(){
        System.out.print("Informe o Nome do Funcionário: ");
        nome=entrada.nextLine();
        return nome;
    }
    public void ExibeHolerite(double sa, double sn,double sf,double vl_inss, double vl_ir,String nm){
        System.out.println("**************HOLERITE**********");
        System.out.println("* Nome do Funcionário: "+nm);
        System.out.println("* Salário Atual:"+sa);
        System.out.println("* Salário Bruto com Aumento:"+sn);
        System.out.println("* Desconto do INSS:"+vl_inss);
        System.out.println("* Desconto do IR:"+vl_ir);
        System.out.println("* Salário Líquido:"+sf);
        System.out.println("*********************************");
        
        
    }
    public void Sair(){
        System.out.println("SISTEMA ENCERRADO!");
        System.exit(0);
    }
    
    
}
