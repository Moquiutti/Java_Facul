/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holerite;

/**
 *
 * @author lcmlu
 */
public class Holerite {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Calculos rh =new Calculos();
        rh.EntrarNome();
        rh.ExibeMsg();
        rh.AumentoSalarial(rh.salario_atual);
        rh.CalcSalarioNovo(rh.valor_aumento, rh.salario_atual);
        rh.CalcValorInss(rh.salario_novo);
        rh.CalcValorIr(rh.salario_novo);
        rh.CalcSalFinal(rh.salario_novo, rh.vlr_inss, rh.vlr_ir);
        rh.ExibeHolerite(rh.salario_atual, rh.salario_novo, rh.salario_final, rh.vlr_inss, rh.vlr_ir, rh.nome);
        rh.Sair();
        
        
        
    }
    
}
